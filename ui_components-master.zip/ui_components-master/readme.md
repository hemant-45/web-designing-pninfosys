# HTML & CSS UI Components

> This is a repo of UI components written in HTML & CSS. The designs come from [UI Design Daily](https://uidesigndaily.com).

I will be adding 3 more per month and creating a video for them at [Traversy Media](https://www.youtube.com/channel/UC29ju8bIPH5as8OGnQzwJyA). Feel free to use these however you would like.

## Links to original designs:

1. [Blog Cards](https://uidesigndaily.com/posts/sketch-blog-cards-post-article-thumbnail-day-997)
2. [Login](https://uidesigndaily.com/posts/sketch-login-log-in-authentication-features-day-1022)
3. [Ads Manager](https://uidesigndaily.com/posts/sketch-ads-manager-table-list-day-1049)
