# Responsive Card Neon Glass
## [Watch it on youtube]()
### Responsive Card Neon Glass
Beautiful neon glass cards using HTML & CSS with animation effects.
Don't forget to join the channel for more videos like this. [Bedimcode](https://www.youtube.com/c/Bedimcode)

![Card Neon](/preview.png)
