# Glassmorphism Card Responsive
## [Watch it on youtube](https://youtu.be/XIbWQYoEnCk)
### Glassmorphism Card Responsive
Beautiful and simple responsive cards with Glass Morphism ui style, using Html and Css.

Don't forget to join the channel for more videos like this. [Bedimcode](https://www.youtube.com/c/Bedimcode)
